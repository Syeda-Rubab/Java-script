//They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these items.
var person = {
    name: 'Rubab',
    age: 21,
    occupation: 'Web devloper',
    hobbies: ['Reading', 'Shopping']
};
console.log(person);
