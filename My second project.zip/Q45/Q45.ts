//Cars: Write a function that stores information about a car in a Object. The function should always receive a manufacturer and a model name. It should then accept an arbitrary number of keyword arguments. Call the function with the required information and two other name-value pairs, such as a color or an optional feature. Print the Object that’s returned to make sure all the information was stored correctly.
function carInfo(manufacturer: string, model: string, ...options: any[]) {
    const car = {
      manufacturer: manufacturer,
      model: model,
    };
  
    // Add any additional options to the car object
    options.forEach((option) => {
      const key = Object.keys(option)[0];
      const value = option[key];
      car[key] = value;
    });
  
    return car;
  }
  
  // Call the function with required and optional arguments
  const car1 = carInfo("Mercedes", "2023", { color: "White" }, { sunroof: true });
  console.log(car1);