//Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look something like the following, including the quotation marks:
//Aristotle once said,"It is during our darkest moments that we must focus to see the light."
var name1 = ("Hazrat Ali said");
console.log("".concat(name1, "\u201CThe best deed of a great man is to forgive and forget\""));
