//Guest List: If you could invite anyone, living or deceased, to dinner, who would you invite? Make a list that includes at least three people you’d like to invite to dinner. Then use your list to print a message to each person, inviting them to dinner.
var gueslist = ["Kaif", "Salaar", "Mahir", "Jihan"];
for (var i = 0; i < gueslist.length; i++) {
    console.log("Dear ".concat(gueslist[i], ", \n    I would like to invitation for you to join me for dinner.\n    Best Regards, \n    [Syeda Rubab]\n    "));
}
