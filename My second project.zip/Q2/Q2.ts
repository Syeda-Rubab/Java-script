//Personal Message: Store a person’s name in a variable, and print a message to that person. Your message should be simple, such as, “Hello Eric, would you like to learn some Python today?”
var a : string ="Rubab";
console.log("Hello "+ a + "Today is our first class");