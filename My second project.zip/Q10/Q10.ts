//Adding Comments: Choose two of the programs you’ve written, and add at least one comment to each. If you don’t have anything specific to write because your programs are too simple at this point, just add your name and the current date at the top of each program file. Then write one sentence describing what the program does

//My name store in variable. 
// this line is commented.
var username: string = "Rubab";
console.log(username);

/*thi is 
a Multi line Comment
commented line can't be executed in our 
 code*/