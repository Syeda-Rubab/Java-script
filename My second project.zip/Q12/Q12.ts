//Greetings: Start with the array you used in Exercise 11, but instead of just printing each person’s name, print a message to them. The text of each message should be the same, but each message should be personalized with the person’s name.
let names: string[] = ["Rubab", "Fazila", "Sahifa"];
console.log("Welcome in Developing Field " + names[0] + "\nWelcome in Developing Field  " + names[1]
    + " \nWelcome in Developing Field " + names[2]);