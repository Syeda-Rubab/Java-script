//Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
let famous_person:string="Hazrat Ali R.A";
let message:string="The best deed of a great man is to forgive and forget.";
console.log(` "${famous_person} Once said, ${message}" `);