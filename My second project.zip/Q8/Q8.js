//You should create four lines that look like this:
//Your output should simply be four lines with the number 8 appearing once on each line.
console.log(5 + 3);
console.log(18 - 10);
console.log(4 * 2);
console.log(16 / 2);
