//Dinner Guests: Working with one of the programs from Exercises 14 through 18, print a message indicating the number of people you are inviting to dinner.
const guestName: string[] = ["Areej", "Asmara", "Hafsa"];
console.log(`The ${guestName.length} guest are invited`);