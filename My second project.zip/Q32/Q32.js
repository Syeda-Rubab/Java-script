//Checking Usernames: Do the following to create a program that simulates how websites ensure that everyone has a unique username.
//• Make a list of five or more usernames called current_users.
//• Make another list of five usernames called new_users. Make sure one or two of the new usernames are also in the current_users list.
//• Loop through the new_users list to see if each new username has already been used. If it has, print a message that the person will need to enter a new username. If a username has not been used, print a message saying that the username is available.
//• Make sure your comparison is case insensitive. If 'John' has been used, 'JOHN' should not be accepted.
var firstArray = ["Rubab", "Tanzila", "Fazila", "Sahifa", "Alizah"];
var secarray = ["Imama", "Haya", "Kashmala", "Liza", "Pareeshay"];
for (var _i = 0, secarray_1 = secarray; _i < secarray_1.length; _i++) {
    var newUser = secarray_1[_i];
    var isUserTaken = false;
    for (var _a = 0, firstArray_1 = firstArray; _a < firstArray_1.length; _a++) {
        var currentUser = firstArray_1[_a];
        if (newUser.toLowerCase() === currentUser.toLowerCase()) {
            console.log("The username ".concat(newUser, " is already taken. Please choose a different username."));
            isUserTaken = true;
            break;
        }
    }
    if (!isUserTaken) {
        console.log("The username ".concat(newUser, " is available."));
    }
}
